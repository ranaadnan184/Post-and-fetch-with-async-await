import React, { useState } from "react";
import "./style.css";
import Optiondata from './Optiondata'
import Subject12 from './SubjectData'
const Newreactboot = () => {
  const [info, setInfo] = useState({
    name: "",
    addres: "",
    phone: "",
    email: "",
    select: "",
    gender: "",
    birthday: "",
  });
  const Handlechange = (event) => {
    const { name, value } = event.target;

    setInfo((preValue) => {
      return {
        ...preValue,
        [name]: value,
      };
    });
  };
  const handlesubmit = async () => {
    let data = { info };
    await fetch("https://fakestoreapi.com/users/", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    }).then((result) => {
      result.json().then((resp) => {
        console.log("resp", resp);
      });
    });
  };
  return (
    <div>
      <section className="vh-100 gradient-custom">
        <div className="container py-5 h-100">
          <div className="row justify-content-center align-items-center h-100">
            <div className="col-12 col-lg-9 col-xl-7">
              <div
                className="card shadow-2-strong card-registration  check-form"
                style={{ borderRadius: 15 }}
              >
                <div className="card-body p-4 p-md-5">
                  <h3 className="mb-4 pb-2 pb-md-0 mb-md-5">
                    Registration Form
                  </h3>

                  <div className="inner-boot-react">
                    <div className="row">
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <label className="form-label text-lable">Name</label>

                          <input
                            type="text"
                            id="firstName"
                            name="name"
                            className="form-control form-control-lg"
                            onChange={Handlechange}
                          />
                        </div>
                      </div>
                      <div className="col-md-6 mb-4">
                        <div className="form-outline">
                          <label className="form-label  text-lable">Address</label>

                          <input
                            type="text"
                            id="lastName"
                            name="addres"
                            value={info.addres}
                            className="form-control form-control-lg"
                            onChange={Handlechange}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4 d-flex align-items-center">
                        <div className="form-outline datepicker w-100">
                          <label htmlFor="birthdayDate" className="form-label  text-lable">
                            Birthday
                          </label>

                          <input
                            type="date"
                            name="birthday"
                            value={info.birthday}
                            className="form-control form-control-lg"
                            id="birthdayDate"
                            onChange={Handlechange}
                          />
                        </div>
                      </div>
                  
                      <h6 id="gender-1">Gender: </h6>
                      <br></br>
                      <select
                          className="select form-control-lg select-male"
                          name="gender"
                           value={info.gender}
                          onChange={Handlechange}
                        >
                       
                          {
                            Optiondata.map((item,index)=>{
                                return(
                                    <option key={index} >{item.relation}</option>
                                )
                            })
                          }
                        
                       
                        </select>

                   
                    </div>
                    <div className="row">
                      <div className="col-md-6 mb-4 pb-2">
                        <div className="form-outline">
                          <label className="form-label  text-lable">Email</label>

                          <input
                            type="email"
                            id="emailAddress"
                            name="email"
                            value={info.email}
                            className="form-control form-control-lg"
                            onChange={Handlechange}
                          />
                        </div>
                      </div>
                      <div className="col-md-6 mb-4 pb-2">
                        <div className="form-outline">
                          <label className="form-label  text-lable">Phone Number</label>

                          <input
                            type="tel"
                            id="phoneNumber"
                            name="phone"
                            value={info.phone}
                            className="form-control form-control-lg"
                            onChange={Handlechange}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12">
                        <label className="form-label select-label  text-lable">
                          Choose option
                        </label>

                        <select
                          className="select form-control-lg second-select"
                          name="select"
                          value={info.select}
                          onChange={Handlechange}
                        >
                          <option value={1} disabled>
                            Choose option
                          </option>
                          {
                            Subject12.map((items,index)=>{
                                return(
                                    <option key={index} >{items.Subject}</option>
                                )
                            }) 
                          }
                        </select>
                      </div>
                    </div>
                    <div className="mt-4 pt-2">
                      <button onClick={handlesubmit}>Click me</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div>
    
      </div>
    </div>
  );
};

export default Newreactboot;
