  const Optiondata=[
    {
  relation:"Male"
},
{
    relation:"Female"
  },
  {
    relation:"Others"
  },
]


export default Optiondata


