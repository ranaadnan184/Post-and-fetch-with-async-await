const Subject12=[
    {
        Subject:"English"
    },
    {
        Subject:"Urdo"
    },
    {
        Subject:"Islamiat"
    },
    {
        Subject:"Physics"
    },
    {
        Subject:"Chemistry"
    },
   
]

export default Subject12