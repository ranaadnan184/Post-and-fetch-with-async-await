import React, { useState } from "react";
import './Style.Module.css'
const Naqash = () => {
  const [info, setInfo] = useState({
    id:"",
    name:"",
    addres:"",
    phone:"",
    email:"",
    city:""
  });


  const Handlechange = (event) => {
    const { name, value } = event.target;

    setInfo((preValue) => {
      return {
        ...preValue,
        [name] : value,
      };
    });
  };
  const handlesubmit= async ()=> {
    let data = {info};
    await fetch("https://fakestoreapi.com/users/", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        // accept: "application/json",
        "Content-Type": "application/json",
      },
    }).then((result) => {
      result.json().then((resp) => {
        console.log("resp", resp);
      });
    });
  }

  return (
    <div className="set-N-main">
      <div className="set-N-second">
      <div>
        <h2 id="lable">Id:</h2>
        <input
          type="text"
          name="id"
          placeholder="Enter ID"
          value={info.id}
          onChange={Handlechange}
        />
      </div>{" "}
      <div>
        <h2 id="lable">Name:</h2>
        <input
          type="text"
          name="name"
          placeholder="Enter Name"
          value={info.name}
          onChange={Handlechange}
        />
      </div>{" "}
      <div id="lable">
        <h2>Address:</h2>
        <input
          type="text"
          name="addres"
          placeholder="Enter Address"
          value={info.addres}
          onChange={Handlechange}
        />
      </div>{" "}
      <div>
        <h2 id="lable">Phone:</h2>
        <input
          type="text"
          name="phone"
          placeholder="Enter phone"
          value={info.phone}
          onChange={Handlechange}
        />
      </div>{" "}
      <div>
        <h2 id="lable">Email:</h2>
        <input
          type="text"
          name="email"
          placeholder="Enter Email"
          value={info.email}
          onChange={Handlechange}
        />
      </div>{" "}
      <div>
        <h2 id="lable">City:</h2>
        <input
          type="text"
          name="city"
          placeholder="Enter City"
          value={info.city}
          onChange={Handlechange}
        />
      </div>
      <div>
        <button onClick={handlesubmit}>Submit</button>
      </div>
      </div>
    </div>
  );
};

export default Naqash;
