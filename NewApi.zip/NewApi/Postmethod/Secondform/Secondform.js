import React, { useState } from "react";
import "./second.css";
const Secondform = () => {
  const [info, setInfo] = useState({
    name: "",
    addres: "",
    password: "",
    city: "",
    email: "",
    birthday: "",
  });
  const Handlechange = (event) => {
    const { name, value } = event.target;

    setInfo((preValue) => {
      return {
        ...preValue,
        [name]: value,
      };
    });
  };
  const handlesubmit = async (event) => {
    event.preventDefault();
    
    let data = { info };
    const response = await fetch("https://fakestoreapi.com/users/", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    });
    const seconddata = await response.json();
    console.log(seconddata);
  };
  return (
    <div>
    <form onSubmit={handlesubmit}>
      <section
        className="vh-100 bg-image"
        style={{
          backgroundImage:
            'url("https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp")',
        }}
      >
        <div className="mask d-flex align-items-center h-100 gradient-custom-3">
          <div className="container h-100  main-1">
            <div className="row d-flex justify-content-center align-items-center h-100 main-1">
              <div className="col-12 col-md-6 col-lg-6 col-xl-6  main-1 ">
                <div className="card" style={{ borderRadius: 15 }}>
                  <div className="card-body p-5 main-1 main-secon-form-11">
                    <h2 className="text-uppercase text-center mb-5 main-1">
                      Create an account
                    </h2>

                    <div className="form-outline mb-4 main-1">
                      <label className="form-label">Your Name</label>

                      <input
                        type="text"
                        id="form3Example1cg"
                        name="name"
                        value={info.name}
                        className="form-control form-control-lg"
                        onChange={Handlechange}
                      />
                    </div>
                    <div className="form-outline mb-4">
                      <label className="form-label">Your Email</label>

                      <input
                        type="email"
                        id="form3Example3cg"
                        name="email"
                        value={info.email}
                        className="form-control form-control-lg"
                        onChange={Handlechange}
                      />
                    </div>
                    <div className="form-outline mb-4">
                      <label className="form-label">Password</label>

                      <input
                        type="text"
                        id="form3Example4cg"
                        name="password"
                        value={info.password}
                        className="form-control form-control-lg"
                        onChange={Handlechange}
                      />
                    </div>
                    <div className="form-outline mb-4">
                      <label className="form-label">City</label>

                      <input
                        type="text"
                        id="form3Example4cg"
                        name="city"
                        value={info.city}
                        className="form-control form-control-lg"
                        onChange={Handlechange}
                      />
                    </div>
                    <div className="form-outline mb-4">
                      <label className="form-label">Address</label>

                      <input
                        type="text"
                        id="form3Example4cg"
                        name="addres"
                        value={info.addres}
                        className="form-control form-control-lg"
                        onChange={Handlechange}
                      />
                    </div>
                    <div className="form-outline mb-4">
                      <label className="form-label">Birthday</label>

                      <input
                        type="date"
                        id="form3Example4cdg"
                        name="birthday"
                        value={info.birthday}
                        className="form-control form-control-lg"
                        onChange={Handlechange}
                      />
                    </div>
                    <div className="form-check d-flex justify-content-center mb-5">
                      <input
                        className="form-check-input me-2 check-box-1"
                        type="checkbox"
                        defaultValue
                        id="form2Example3cg"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="form2Example3g"
                      >
                        I agree all statements in{" "}
                        <a href="#!" className="text-body">
                          <u>Terms of service</u>
                        </a>
                      </label>
                    </div>
                    <div className="d-flex justify-content-center">
                      <button
                        // onClick={handlesubmit}
                        className="btn btn-success btn-block btn-lg gradient-custom-4 text-body"
                      >
                        Register
                      </button>
                    </div>
                    <p className="text-center text-muted mt-5 mb-0">
                      Have already an account?{" "}
                      <a href="#!" className="fw-bold text-body">
                        <u>Login here</u>
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      </form>
    </div>
  );
};

export default Secondform;
